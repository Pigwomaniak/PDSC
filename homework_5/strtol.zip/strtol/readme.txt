Name your function 'strtol' and place it in the file named 'strtol.c'.
Library function is used, if you compile test_strtol.c alone.
Your function will be used, if you compile both files together.
